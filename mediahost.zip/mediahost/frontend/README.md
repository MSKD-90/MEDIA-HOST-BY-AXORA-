# MediaHost Frontend

React + Vite + Tailwind CSS frontend for the MediaHost API.

## Setup

```bash
cd frontend
npm install
cp .env.example .env   # point VITE_API_URL at your backend, include /api
npm run dev             # http://localhost:5173
```

Build for production:

```bash
npm run build      # outputs to dist/
npm run preview    # serve the production build locally
```

## Folder structure

```
frontend/src/
  api/axios.js            Configured axios instance (auth header, error normalization)
  context/AuthContext.jsx  Login/register/logout + session restore on load
  components/               Navbar, UploadZone, MediaCard, MediaGrid,
                             LoadingSkeleton, ProtectedRoute, Toast
  pages/                     Home, Login, Register, Dashboard, MediaView,
                             AdminDashboard, NotFound
  App.jsx                    Route definitions
  main.jsx                   Entry point
```

## Notes

- All data is API-driven — nothing is hardcoded. `VITE_API_URL` is the only
  environment-specific value.
- The JWT is stored in `localStorage` under `mediahost_token`; every request
  attaches it automatically via an axios interceptor, and a 401 response
  clears it and signs the user out.
- Guests can upload from the Home page without an account; logging in adds
  ownership so uploads show up in the Dashboard and can be deleted later.
- Tailwind design tokens (colors, shadows, animation) live in `tailwind.config.js`.
