import React, { useCallback, useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import UploadZone from '../components/UploadZone';
import MediaGrid from '../components/MediaGrid';

export default function Dashboard() {
  const { user } = useAuth();
  const showToast = useToast();
  const [media, setMedia] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMedia = useCallback(async () => {
    try {
      const res = await api.get('/media/my');
      setMedia(res.data.media);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchMedia();
  }, [fetchMedia]);

  const handleUploaded = (item) => setMedia((prev) => [item, ...prev]);

  const handleDelete = async (id) => {
    const prev = media;
    setMedia((m) => m.filter((item) => item.id !== id));
    try {
      await api.delete(`/media/${id}`);
      showToast('File deleted', 'success');
    } catch (err) {
      setMedia(prev);
      showToast(err.message, 'error');
    }
  };

  const totalSize = media.reduce((sum, m) => sum + (m.filesize || 0), 0);
  const totalSizeMb = (totalSize / (1024 * 1024)).toFixed(1);

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-10">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4 animate-fadeUp">
        <div>
          <h1 className="text-2xl font-bold text-ink">Hey {user?.username} 👋</h1>
          <p className="mt-1 text-sm text-muted">
            {media.length} file{media.length === 1 ? '' : 's'} · {totalSizeMb} MB stored
          </p>
        </div>
      </div>

      <div className="mb-10 animate-fadeUp">
        <UploadZone onUploaded={handleUploaded} />
      </div>

      <h2 className="mb-4 text-lg font-bold text-ink">Your uploads</h2>
      <MediaGrid
        items={media}
        loading={loading}
        onDelete={handleDelete}
        canDelete
        emptyMessage="You haven't uploaded anything yet — drop a file above to get started."
      />
    </div>
  );
}
