import React, { useCallback, useEffect, useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import api from '../api/axios';
import { useToast } from '../components/Toast';
import MediaGrid from '../components/MediaGrid';

export default function AdminDashboard() {
  const showToast = useToast();
  const [media, setMedia] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);

  const fetchAll = useCallback(async () => {
    try {
      const res = await api.get('/media', { params: { limit: 100 } });
      setMedia(res.data.media);
      setTotal(res.data.pagination.total);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const handleDelete = async (id) => {
    const prev = media;
    setMedia((m) => m.filter((item) => item.id !== id));
    try {
      await api.delete(`/media/${id}`);
      showToast('File removed', 'success');
    } catch (err) {
      setMedia(prev);
      showToast(err.message, 'error');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-10">
      <div className="mb-8 flex items-center gap-3 animate-fadeUp">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent-soft text-accent">
          <ShieldCheck size={18} />
        </span>
        <div>
          <h1 className="text-xl font-bold text-ink">Admin — all media</h1>
          <p className="text-sm text-muted">{total} files across every user</p>
        </div>
      </div>

      <MediaGrid
        items={media}
        loading={loading}
        onDelete={handleDelete}
        canDelete
        emptyMessage="No media has been uploaded yet."
      />
    </div>
  );
}
