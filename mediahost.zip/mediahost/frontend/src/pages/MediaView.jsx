import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Link2, Check, Download, ArrowLeft, Eye } from 'lucide-react';
import api from '../api/axios';
import { useToast } from '../components/Toast';

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / 1024 ** i).toFixed(1)} ${units[i]}`;
}

export default function MediaView() {
  const { id } = useParams();
  const showToast = useToast();
  const [media, setMedia] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api
      .get(`/media/${id}`)
      .then((res) => {
        if (!active) return;
        setMedia(res.data.media);
        // SEO: set a descriptive document title for this shared media page.
        document.title = `${res.data.media.originalName} — MediaHost`;
      })
      .catch(() => active && setNotFound(true))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [id]);

  const copyLink = async () => {
    await navigator.clipboard.writeText(media.publicUrl);
    setCopied(true);
    showToast('Link copied to clipboard', 'success');
    setTimeout(() => setCopied(false), 1800);
  };

  if (loading) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-border border-t-accent" />
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-5 text-center">
        <h1 className="text-xl font-bold text-ink">This file isn't here anymore</h1>
        <p className="mt-2 text-sm text-muted">It may have been deleted, or the link is incorrect.</p>
        <Link
          to="/"
          className="mt-6 rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-accent"
        >
          Upload something new
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-5 pb-24 pt-8">
      <Link to="/" className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-ink">
        <ArrowLeft size={15} /> Back to MediaHost
      </Link>

      <div className="animate-fadeUp overflow-hidden rounded-2xl border border-border bg-white shadow-card">
        <div className="flex items-center justify-center bg-surface p-4">
          {media.filetype === 'video' ? (
            <video src={media.publicUrl} controls className="max-h-[70vh] w-full rounded-lg" />
          ) : (
            <img
              src={media.publicUrl}
              alt={media.originalName}
              className="max-h-[70vh] w-full rounded-lg object-contain"
            />
          )}
        </div>

        <div className="flex flex-col gap-4 border-t border-border p-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <p className="truncate font-semibold text-ink">{media.originalName}</p>
            <p className="mt-0.5 flex items-center gap-2 text-xs text-muted">
              {formatBytes(media.filesize)}
              <span className="h-1 w-1 rounded-full bg-border" />
              <span className="flex items-center gap-1">
                <Eye size={12} /> {media.views} views
              </span>
              <span className="h-1 w-1 rounded-full bg-border" />
              {new Date(media.createdAt).toLocaleDateString()}
            </p>
          </div>

          <div className="flex shrink-0 gap-2">
            <button
              onClick={copyLink}
              className="flex items-center gap-1.5 rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white transition-all hover:bg-accent active:scale-[0.97]"
            >
              {copied ? <Check size={15} /> : <Link2 size={15} />}
              {copied ? 'Copied' : 'Copy link'}
            </button>
            <a
              href={media.publicUrl}
              download={media.originalName}
              className="flex items-center gap-1.5 rounded-lg border border-border px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-surface"
            >
              <Download size={15} />
            </a>
          </div>
        </div>

        <div className="border-t border-border bg-surface/60 px-5 py-3">
          <p className="truncate font-mono text-xs text-muted">{media.publicUrl}</p>
        </div>
      </div>
    </div>
  );
}
