import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap, Lock, Globe2 } from 'lucide-react';
import UploadZone from '../components/UploadZone';
import MediaGrid from '../components/MediaGrid';
import { useAuth } from '../context/AuthContext';

const FEATURES = [
  { icon: Zap, title: 'Instant links', desc: 'Every upload gets a permanent public URL the moment it finishes.' },
  { icon: Lock, title: 'Your files, your control', desc: 'Sign in to manage, organize, and delete everything you upload.' },
  { icon: Globe2, title: 'Embed anywhere', desc: 'Direct links work in forums, chats, READMEs, and any website.' },
];

export default function Home() {
  const { user } = useAuth();
  const [recentUploads, setRecentUploads] = useState([]);

  const handleUploaded = (media) => {
    setRecentUploads((prev) => [media, ...prev]);
  };

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-14">
      <section className="mx-auto max-w-2xl text-center animate-fadeUp">
        <h1 className="text-[2.4rem] font-extrabold leading-[1.1] tracking-tight text-ink sm:text-5xl">
          Share images and video in one drop
        </h1>
        <p className="mx-auto mt-4 max-w-lg text-base text-muted sm:text-lg">
          Free, fast media hosting. Drop a file, get a link, share it anywhere — no account needed.
        </p>
      </section>

      <section className="mx-auto mt-10 max-w-2xl animate-fadeUp">
        <UploadZone onUploaded={handleUploaded} />
        {!user && (
          <p className="mt-3 text-center text-xs text-muted">
            Uploading as a guest.{' '}
            <Link to="/register" className="font-medium text-accent hover:underline">
              Create a free account
            </Link>{' '}
            to keep every upload organized in one dashboard.
          </p>
        )}
      </section>

      {recentUploads.length > 0 && (
        <section className="mx-auto mt-14 max-w-5xl">
          <h2 className="mb-4 text-lg font-bold text-ink">Just uploaded</h2>
          <MediaGrid items={recentUploads} canDelete={false} />
        </section>
      )}

      <section className="mx-auto mt-24 grid max-w-4xl grid-cols-1 gap-6 sm:grid-cols-3">
        {FEATURES.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="rounded-2xl border border-border bg-white p-5 shadow-soft">
            <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl bg-accent-soft text-accent">
              <Icon size={17} />
            </span>
            <h3 className="text-sm font-semibold text-ink">{title}</h3>
            <p className="mt-1 text-[13px] leading-relaxed text-muted">{desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
