import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Link2, Trash2, Film, Eye, Check } from 'lucide-react';
import { useToast } from './Toast';

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / 1024 ** i).toFixed(1)} ${units[i]}`;
}

export default function MediaCard({ media, onDelete, canDelete }) {
  const [copied, setCopied] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const showToast = useToast();

  const copyLink = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    await navigator.clipboard.writeText(media.publicUrl);
    setCopied(true);
    showToast('Link copied to clipboard', 'success');
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDelete = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!confirmingDelete) {
      setConfirmingDelete(true);
      setTimeout(() => setConfirmingDelete(false), 3000);
      return;
    }
    onDelete?.(media.id);
  };

  return (
    <Link
      to={`/media/${media.id}`}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-white shadow-card transition-all duration-200 hover:-translate-y-0.5 hover:shadow-cardHover"
    >
      <div className="relative aspect-square w-full overflow-hidden bg-surface">
        {media.filetype === 'video' ? (
          <>
            <video src={media.publicUrl} className="h-full w-full object-cover" muted preload="metadata" />
            <div className="absolute inset-0 flex items-center justify-center bg-ink/10">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-ink shadow-soft">
                <Film size={16} />
              </span>
            </div>
          </>
        ) : (
          <img
            src={media.publicUrl}
            alt={media.originalName}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        )}

        <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-gradient-to-t from-ink/70 via-ink/0 to-transparent p-2.5 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
          <button
            onClick={copyLink}
            className="flex items-center gap-1 rounded-lg bg-white/95 px-2.5 py-1.5 text-xs font-semibold text-ink shadow-soft transition-transform active:scale-95"
          >
            {copied ? <Check size={13} className="text-success" /> : <Link2 size={13} />}
            {copied ? 'Copied' : 'Copy link'}
          </button>
          {canDelete && (
            <button
              onClick={handleDelete}
              className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold shadow-soft transition-all active:scale-95 ${
                confirmingDelete ? 'bg-danger text-white' : 'bg-white/95 text-danger'
              }`}
            >
              <Trash2 size={13} />
              {confirmingDelete ? 'Confirm' : 'Delete'}
            </button>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 p-3">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-ink">{media.originalName}</p>
          <p className="text-[11px] text-muted">{formatBytes(media.filesize)}</p>
        </div>
        <span className="flex shrink-0 items-center gap-1 text-[11px] text-muted">
          <Eye size={12} /> {media.views ?? 0}
        </span>
      </div>
    </Link>
  );
}
