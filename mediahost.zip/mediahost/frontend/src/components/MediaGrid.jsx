import React from 'react';
import { ImageOff } from 'lucide-react';
import MediaCard from './MediaCard';
import LoadingSkeleton from './LoadingSkeleton';

export default function MediaGrid({ items, loading, onDelete, canDelete, emptyMessage }) {
  if (loading) return <LoadingSkeleton />;

  if (!items || items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-20 text-center">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-surface text-muted">
          <ImageOff size={20} />
        </div>
        <p className="text-sm font-medium text-ink">{emptyMessage || 'Nothing here yet'}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {items.map((media) => (
        <MediaCard key={media.id} media={media} onDelete={onDelete} canDelete={canDelete} />
      ))}
    </div>
  );
}
