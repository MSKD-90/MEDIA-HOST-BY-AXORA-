import React, { useCallback, useRef, useState } from 'react';
import { UploadCloud, Film, Image as ImageIcon, X, Check, AlertCircle } from 'lucide-react';
import api from '../api/axios';
import { useToast } from './Toast';

const ACCEPTED_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif',
  'video/mp4',
  'video/webm',
];

const MAX_SIZE_MB = 50;

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / 1024 ** i).toFixed(1)} ${units[i]}`;
}

// Each entry in the queue tracks its own upload lifecycle so multiple
// files can upload in parallel with independent progress bars.
function QueueItem({ item, onRemove }) {
  const isImage = item.file.type.startsWith('image/');
  const isDone = item.status === 'done';
  const isError = item.status === 'error';

  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-white p-3 shadow-soft animate-fadeUp">
      <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-surface">
        {isImage ? (
          <img src={item.previewUrl} alt="" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted">
            <Film size={20} />
          </div>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-sm font-medium text-ink">{item.file.name}</p>
          {isDone && <Check size={16} className="shrink-0 text-success" />}
          {isError && <AlertCircle size={16} className="shrink-0 text-danger" />}
        </div>
        <p className="text-xs text-muted">{formatBytes(item.file.size)}</p>

        {!isError ? (
          <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-surface">
            <div
              className={`h-full rounded-full transition-all duration-200 ease-out ${
                isDone ? 'bg-success' : 'bg-accent'
              }`}
              style={{ width: `${item.progress}%` }}
            />
          </div>
        ) : (
          <p className="mt-1 text-xs text-danger">{item.error}</p>
        )}
      </div>

      {(isDone || isError) && (
        <button
          onClick={() => onRemove(item.id)}
          className="shrink-0 rounded-md p-1 text-muted hover:bg-surface hover:text-ink"
          aria-label="Remove"
        >
          <X size={15} />
        </button>
      )}
    </div>
  );
}

export default function UploadZone({ onUploaded }) {
  const [isDragging, setIsDragging] = useState(false);
  const [queue, setQueue] = useState([]);
  const inputRef = useRef(null);
  const showToast = useToast();

  const validateFile = (file) => {
    if (!ACCEPTED_TYPES.includes(file.type)) {
      return `Unsupported file type. Use JPG, PNG, WEBP, GIF, MP4, or WEBM.`;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      return `File exceeds the ${MAX_SIZE_MB}MB limit.`;
    }
    return null;
  };

  const uploadFile = useCallback(
    (file) => {
      const id = Date.now() + Math.random();
      const previewUrl = file.type.startsWith('image/') ? URL.createObjectURL(file) : null;

      const validationError = validateFile(file);
      if (validationError) {
        setQueue((prev) => [
          ...prev,
          { id, file, previewUrl, progress: 0, status: 'error', error: validationError },
        ]);
        return;
      }

      setQueue((prev) => [...prev, { id, file, previewUrl, progress: 0, status: 'uploading' }]);

      const formData = new FormData();
      formData.append('file', file);

      api
        .post('/media/upload', formData, {
          onUploadProgress: (evt) => {
            const percent = Math.round((evt.loaded * 100) / evt.total);
            setQueue((prev) => prev.map((q) => (q.id === id ? { ...q, progress: percent } : q)));
          },
        })
        .then((res) => {
          setQueue((prev) =>
            prev.map((q) => (q.id === id ? { ...q, progress: 100, status: 'done' } : q))
          );
          onUploaded?.(res.data.media);
        })
        .catch((err) => {
          setQueue((prev) =>
            prev.map((q) =>
              q.id === id ? { ...q, status: 'error', error: err.message } : q
            )
          );
          showToast(err.message, 'error');
        });
    },
    [onUploaded, showToast]
  );

  const handleFiles = useCallback(
    (fileList) => {
      Array.from(fileList).forEach(uploadFile);
    },
    [uploadFile]
  );

  const onDrop = useCallback(
    (e) => {
      e.preventDefault();
      setIsDragging(false);
      if (e.dataTransfer.files?.length) handleFiles(e.dataTransfer.files);
    },
    [handleFiles]
  );

  const removeItem = (id) => setQueue((prev) => prev.filter((q) => q.id !== id));

  return (
    <div className="w-full">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') inputRef.current?.click();
        }}
        className={`group relative flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-16 text-center transition-all duration-200 ${
          isDragging
            ? 'scale-[1.01] border-accent bg-accent-soft'
            : 'border-border bg-surface hover:border-accent/50 hover:bg-accent-soft/40'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPTED_TYPES.join(',')}
          className="hidden"
          onChange={(e) => e.target.files?.length && handleFiles(e.target.files)}
        />

        <div
          className={`mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-white shadow-soft transition-transform duration-200 ${
            isDragging ? 'scale-110' : 'group-hover:scale-105'
          }`}
        >
          <UploadCloud
            size={28}
            strokeWidth={1.8}
            className={isDragging ? 'text-accent' : 'text-ink'}
          />
        </div>

        <p className="text-base font-semibold text-ink">
          {isDragging ? 'Drop it right here' : 'Drag & drop images or video'}
        </p>
        <p className="mt-1 text-sm text-muted">
          or <span className="font-medium text-accent">browse from your device</span>
        </p>
        <p className="mt-4 flex items-center gap-3 text-xs text-muted">
          <span className="flex items-center gap-1">
            <ImageIcon size={13} /> JPG · PNG · WEBP · GIF
          </span>
          <span className="h-1 w-1 rounded-full bg-border" />
          <span className="flex items-center gap-1">
            <Film size={13} /> MP4 · WEBM
          </span>
          <span className="h-1 w-1 rounded-full bg-border" />
          <span>up to {MAX_SIZE_MB}MB</span>
        </p>
      </div>

      {queue.length > 0 && (
        <div className="mt-4 flex flex-col gap-2">
          {queue.map((item) => (
            <QueueItem key={item.id} item={item} onRemove={removeItem} />
          ))}
        </div>
      )}
    </div>
  );
}
