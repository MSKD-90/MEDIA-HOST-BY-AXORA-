import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Images, ShieldCheck, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const isActive = (path) => location.pathname === path;

  const linkClass = (path) =>
    `px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
      isActive(path) ? 'text-ink bg-surface' : 'text-muted hover:text-ink hover:bg-surface'
    }`;

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
        <Link to="/" className="flex items-center gap-2 group">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-white transition-transform group-hover:scale-105">
            <Images size={17} strokeWidth={2.4} />
          </span>
          <span className="text-[17px] font-bold tracking-tight text-ink">MediaHost</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          <Link to="/" className={linkClass('/')}>
            Upload
          </Link>
          {user && (
            <Link to="/dashboard" className={linkClass('/dashboard')}>
              My files
            </Link>
          )}
          {user?.role === 'admin' && (
            <Link to="/admin" className={linkClass('/admin')}>
              Admin
            </Link>
          )}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <>
              <div className="flex items-center gap-2 pr-1">
                <span
                  className="flex h-7 w-7 items-center justify-center rounded-full text-[12px] font-semibold text-white"
                  style={{ backgroundColor: user.avatarColor || '#5B5BD6' }}
                >
                  {user.username?.[0]?.toUpperCase()}
                </span>
                <span className="text-sm font-medium text-ink">{user.username}</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-muted transition-colors hover:border-danger/30 hover:bg-danger/5 hover:text-danger"
              >
                <LogOut size={15} />
                Log out
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="rounded-lg px-3 py-2 text-sm font-medium text-muted transition-colors hover:text-ink"
              >
                Log in
              </Link>
              <Link
                to="/register"
                className="rounded-lg bg-ink px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-accent active:scale-[0.97]"
              >
                Sign up free
              </Link>
            </>
          )}
        </div>

        <button
          className="rounded-lg p-2 text-ink md:hidden"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {menuOpen && (
        <div className="border-t border-border px-5 py-3 md:hidden animate-fadeUp">
          <nav className="flex flex-col gap-1">
            <Link to="/" className={linkClass('/')} onClick={() => setMenuOpen(false)}>
              Upload
            </Link>
            {user && (
              <Link to="/dashboard" className={linkClass('/dashboard')} onClick={() => setMenuOpen(false)}>
                My files
              </Link>
            )}
            {user?.role === 'admin' && (
              <Link to="/admin" className={linkClass('/admin')} onClick={() => setMenuOpen(false)}>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck size={14} /> Admin
                </span>
              </Link>
            )}
            <div className="my-2 h-px bg-border" />
            {user ? (
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-left text-sm font-medium text-danger"
              >
                <LogOut size={15} /> Log out
              </button>
            ) : (
              <>
                <Link to="/login" className={linkClass('/login')} onClick={() => setMenuOpen(false)}>
                  Log in
                </Link>
                <Link
                  to="/register"
                  className="mt-1 rounded-lg bg-ink px-3 py-2 text-center text-sm font-semibold text-white"
                  onClick={() => setMenuOpen(false)}
                >
                  Sign up free
                </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
