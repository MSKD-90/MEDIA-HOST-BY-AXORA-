import React from 'react';

export default function LoadingSkeleton({ count = 8 }) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="overflow-hidden rounded-2xl border border-border bg-white shadow-soft">
          <div className="skeleton aspect-square w-full animate-shimmer" />
          <div className="space-y-2 p-3">
            <div className="skeleton h-3 w-3/4 animate-shimmer rounded" />
            <div className="skeleton h-2.5 w-1/3 animate-shimmer rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}
