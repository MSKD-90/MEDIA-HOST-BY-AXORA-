/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0B0E14',
        surface: '#F6F7F9',
        border: '#E6E8EC',
        muted: '#6B7280',
        accent: {
          DEFAULT: '#5B5BD6',
          hover: '#4A49C4',
          soft: '#EEEDFB',
        },
        danger: '#E23E57',
        success: '#0E9F6E',
      },
      fontFamily: {
        sans: [
          'Inter',
          'ui-sans-serif',
          'system-ui',
          '-apple-system',
          'sans-serif',
        ],
      },
      boxShadow: {
        card: '0 1px 2px rgba(11,14,20,0.04), 0 8px 24px -12px rgba(11,14,20,0.10)',
        cardHover: '0 4px 8px rgba(11,14,20,0.06), 0 16px 40px -12px rgba(11,14,20,0.18)',
        soft: '0 1px 3px rgba(11,14,20,0.06)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: 0, transform: 'translateY(8px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-400px 0' },
          '100%': { backgroundPosition: '400px 0' },
        },
        popIn: {
          '0%': { opacity: 0, transform: 'scale(0.96)' },
          '100%': { opacity: 1, transform: 'scale(1)' },
        },
      },
      animation: {
        fadeUp: 'fadeUp 0.45s cubic-bezier(0.16, 1, 0.3, 1) both',
        shimmer: 'shimmer 1.6s infinite linear',
        popIn: 'popIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) both',
      },
    },
  },
  plugins: [],
};
