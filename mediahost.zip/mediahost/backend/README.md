# MediaHost API

Node.js + Express + MongoDB backend for an imgbb-style media hosting platform.

## Setup

```bash
cd backend
npm install
cp .env.example .env   # then edit values (JWT_SECRET, MONGO_URI, etc.)
npm run dev             # nodemon, or: npm start
```

Requires a running MongoDB instance (local, Docker, or Atlas) reachable at `MONGO_URI`.

Optional: create your first admin account:

```bash
npm run seed:admin -- admin@example.com admin StrongPassword123
```

## Folder structure

```
backend/
  config/db.js            MongoDB connection
  models/                 Mongoose schemas (User, Media)
  middleware/              auth (JWT), upload (multer), errorHandler
  controllers/             route logic (authController, mediaController)
  routes/                  Express routers
  utils/                   generateToken, seedAdmin
  uploads/                 uploaded files (served statically at /uploads)
  server.js                app entrypoint
```

## API Reference

All responses are JSON in the shape `{ success: boolean, message?, ...data }`.

### Auth

| Method | Route              | Access  | Body                              |
|--------|---------------------|---------|-------------------------------------|
| POST   | /api/auth/register  | Public  | `{ username, email, password }`     |
| POST   | /api/auth/login     | Public  | `{ email, password }`               |
| GET    | /api/auth/me         | Private | Bearer token                        |

Register/login return `{ token, user }`. Send the token as `Authorization: Bearer <token>` on subsequent requests.

### Media

| Method | Route             | Access             | Notes                                  |
|--------|--------------------|--------------------|------------------------------------------|
| POST   | /api/media/upload   | Public (optional auth) | multipart/form-data, field name `file` |
| GET    | /api/media/my        | Private             | current user's uploads, paginated       |
| GET    | /api/media/:id       | Public              | single item metadata, increments views |
| DELETE | /api/media/:id       | Owner or admin       | removes DB record + file on disk        |
| GET    | /api/media           | Admin only           | all uploads in the system, paginated    |

Upload accepts `jpg, png, webp, gif, mp4, webm` up to `MAX_FILE_SIZE_MB` (default 50MB).

Example upload with curl:

```bash
curl -X POST http://localhost:5000/api/media/upload \
  -H "Authorization: Bearer <token>" \
  -F "file=@/path/to/photo.jpg"
```

## Notes on production readiness

- Passwords hashed with bcrypt (12 rounds).
- JWT auth with configurable expiry.
- Rate limiting on all `/api` routes, tighter limits on `/api/auth`.
- Helmet security headers, CORS allow-list via `CLIENT_ORIGINS`.
- Centralized error handling normalizes Mongoose/Multer/JWT errors into one JSON shape.
- Files stored under `/uploads` with randomized names; swapping to S3/Cloudinary later
  only requires changing `middleware/upload.js` and the `publicUrl` built in
  `mediaController.js` — the rest of the API contract stays identical.
