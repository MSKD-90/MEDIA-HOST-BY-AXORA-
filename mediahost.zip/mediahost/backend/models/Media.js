const mongoose = require('mongoose');

const mediaSchema = new mongoose.Schema(
  {
    filename: {
      // The stored filename on disk (randomized, safe, unique).
      type: String,
      required: true,
    },
    originalName: {
      // The original filename the user uploaded, kept for display/download.
      type: String,
      required: true,
    },
    filetype: {
      type: String,
      enum: ['image', 'video'],
      required: true,
    },
    mimeType: {
      type: String,
      required: true,
    },
    filesize: {
      // Bytes
      type: Number,
      required: true,
    },
    publicUrl: {
      // Absolute URL to the raw file (served statically from /uploads)
      type: String,
      required: true,
    },
    viewUrl: {
      // Absolute URL to the shareable "media view" page (frontend route)
      type: String,
      required: true,
    },
    deleteHash: {
      // Lets an anonymous uploader (or API client) delete a file later
      // without needing an account, similar to imgbb's delete hash concept.
      type: String,
      required: true,
      select: false,
    },
    uploadedBy: {
      // Null for anonymous/guest uploads
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    views: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

// Speeds up "my media" queries sorted by newest first.
mediaSchema.index({ uploadedBy: 1, createdAt: -1 });

mediaSchema.methods.toPublicJSON = function toPublicJSON() {
  return {
    id: this._id,
    originalName: this.originalName,
    filetype: this.filetype,
    mimeType: this.mimeType,
    filesize: this.filesize,
    publicUrl: this.publicUrl,
    viewUrl: this.viewUrl,
    uploadedBy: this.uploadedBy,
    views: this.views,
    createdAt: this.createdAt,
  };
};

module.exports = mongoose.model('Media', mediaSchema);
