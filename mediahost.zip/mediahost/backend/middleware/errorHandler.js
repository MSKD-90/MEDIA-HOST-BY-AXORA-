const multer = require('multer');

// Catches requests to routes that don't exist and forwards a clean 404
// into the centralized error handler below.
const notFound = (req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
};

// Single place where every thrown/next(err) error in the app ends up.
// Normalizes Mongoose, Multer, JWT, and generic errors into one consistent
// JSON error shape so API consumers can rely on a predictable contract.
const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Internal server error';

  // Multer-specific errors (file too large, unexpected field, etc.)
  if (err instanceof multer.MulterError) {
    statusCode = 400;
    if (err.code === 'LIMIT_FILE_SIZE') {
      message = `File is too large. Maximum allowed size is ${
        process.env.MAX_FILE_SIZE_MB || 50
      }MB.`;
    } else {
      message = err.message;
    }
  }

  // Mongoose validation errors
  if (err.name === 'ValidationError') {
    statusCode = 400;
    message = Object.values(err.errors)
      .map((e) => e.message)
      .join(', ');
  }

  // Mongoose duplicate key error (e.g. duplicate email/username)
  if (err.code === 11000) {
    statusCode = 409;
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    message = `That ${field} is already taken.`;
  }

  // Invalid MongoDB ObjectId cast (e.g. malformed :id param)
  if (err.name === 'CastError') {
    statusCode = 400;
    message = `Invalid ID format: ${err.value}`;
  }

  if (process.env.NODE_ENV !== 'production') {
    console.error('[error]', err);
  }

  res.status(statusCode).json({
    success: false,
    message,
  });
};

module.exports = { notFound, errorHandler };
