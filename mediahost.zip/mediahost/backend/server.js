require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const rateLimit = require('express-rate-limit');

const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const mediaRoutes = require('./routes/mediaRoutes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

// --- Database ---------------------------------------------------------
connectDB();

// --- Core middleware ----------------------------------------------------
// Helmet sets a bunch of sane security headers by default.
// crossOriginResourcePolicy is relaxed so uploaded media can be embedded
// (e.g. <img>) from the separate frontend origin.
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);

const allowedOrigins = (process.env.CLIENT_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow non-browser tools (curl, mobile apps, Postman) which send no Origin header,
      // and any origin explicitly listed in CLIENT_ORIGINS.
      if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      callback(new Error(`Origin "${origin}" is not allowed by CORS policy.`));
    },
    credentials: true,
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// Basic rate limiting to slow down brute-force / abuse against the public API.
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300, // requests per window per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests. Please try again later.' },
});
app.use('/api', apiLimiter);

// Tighter limit specifically on auth endpoints to blunt credential stuffing.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many auth attempts. Please try again later.' },
});
app.use('/api/auth', authLimiter);

// --- Static file serving -------------------------------------------------
// Serves everything in /uploads directly, e.g. GET /uploads/163...abc.jpg
app.use(
  '/uploads',
  express.static(path.join(__dirname, process.env.UPLOAD_DIR || 'uploads'), {
    maxAge: '30d', // uploaded files are immutable, safe to cache aggressively
    setHeaders: (res) => {
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    },
  })
);

// --- Health check ---------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.status(200).json({ success: true, message: 'API is healthy', time: new Date().toISOString() });
});

// --- Routes ----------------------------------------------------------------
app.use('/api/auth', authRoutes);
app.use('/api/media', mediaRoutes);

// Friendly root response for anyone hitting the bare API domain.
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'MediaHost API. See /api/health for status.',
    docs: {
      auth: ['POST /api/auth/register', 'POST /api/auth/login', 'GET /api/auth/me'],
      media: [
        'POST /api/media/upload',
        'GET /api/media/my',
        'GET /api/media/:id',
        'DELETE /api/media/:id',
        'GET /api/media (admin only)',
      ],
    },
  });
});

// --- Error handling (must be last) -----------------------------------------
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`[server] MediaHost API running on port ${PORT} (${process.env.NODE_ENV || 'development'})`);
});

module.exports = app;
