const User = require('../models/User');
const generateToken = require('../utils/generateToken');

// A small palette to deterministically assign a pleasant avatar accent color per user.
const PALETTE = ['#5B5BD6', '#2F6FED', '#0E9F6E', '#E8590C', '#D6336C'];

function pickAvatarColor(seed) {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) {
    hash = (hash * 31 + seed.charCodeAt(i)) % PALETTE.length;
  }
  return PALETTE[Math.abs(hash) % PALETTE.length];
}

// @route   POST /api/auth/register
// @access  Public
// @desc    Create a new user account and return a JWT + user profile.
const register = async (req, res, next) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'username, email, and password are all required.',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    const existing = await User.findOne({
      $or: [{ email: email.toLowerCase() }, { username }],
    });
    if (existing) {
      return res.status(409).json({
        success: false,
        message:
          existing.email === email.toLowerCase()
            ? 'An account with that email already exists.'
            : 'That username is already taken.',
      });
    }

    const user = await User.create({
      username,
      email,
      password,
      avatarColor: pickAvatarColor(username),
    });

    const token = generateToken(user);

    res.status(201).json({
      success: true,
      message: 'Account created successfully.',
      token,
      user: user.toSafeJSON(),
    });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/auth/login
// @access  Public
// @desc    Authenticate a user with email + password and return a JWT.
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'email and password are required.',
      });
    }

    // Explicitly select password since the schema excludes it by default.
    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');

    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    const token = generateToken(user);

    res.status(200).json({
      success: true,
      message: 'Logged in successfully.',
      token,
      user: user.toSafeJSON(),
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/auth/me
// @access  Private
// @desc    Return the currently authenticated user's profile.
const getMe = async (req, res, next) => {
  try {
    res.status(200).json({
      success: true,
      user: req.user.toSafeJSON(),
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login, getMe };
