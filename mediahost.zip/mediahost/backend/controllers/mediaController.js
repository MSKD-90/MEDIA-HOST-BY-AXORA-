const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Media = require('../models/Media');
const { ALLOWED_MIME_TYPES, UPLOAD_DIR } = require('../middleware/upload');

const BASE_URL = (process.env.BASE_URL || 'http://localhost:5000').replace(/\/$/, '');
// The frontend app's own base URL, used to build the shareable "view" page link.
// Falls back to BASE_URL if a dedicated client origin isn't configured.
const CLIENT_URL = (process.env.CLIENT_ORIGINS || BASE_URL).split(',')[0].trim().replace(/\/$/, '');

// @route   POST /api/media/upload
// @access  Public (optionalAuth) - guests can upload, logged-in uploads are attributed
// @desc    Accepts a single image/video file, stores it, and returns its public URLs.
const uploadMedia = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file was uploaded. Attach a file under the "file" field.',
      });
    }

    const filetype = ALLOWED_MIME_TYPES[req.file.mimetype];
    const deleteHash = crypto.randomBytes(16).toString('hex');

    const media = await Media.create({
      filename: req.file.filename,
      originalName: req.file.originalname,
      filetype,
      mimeType: req.file.mimetype,
      filesize: req.file.size,
      publicUrl: `${BASE_URL}/uploads/${req.file.filename}`,
      // Placeholder, filled in right after creation once we have the _id.
      viewUrl: '',
      deleteHash,
      uploadedBy: req.user ? req.user._id : null,
    });

    media.viewUrl = `${CLIENT_URL}/media/${media._id}`;
    await media.save();

    res.status(201).json({
      success: true,
      message: 'File uploaded successfully.',
      media: {
        ...media.toPublicJSON(),
        // Only returned once, at upload time, so a guest can save it to delete later.
        deleteHash,
      },
    });
  } catch (err) {
    // Clean up the orphaned file on disk if DB write failed after multer already saved it.
    if (req.file) {
      fs.unlink(path.join(UPLOAD_DIR, req.file.filename), () => {});
    }
    next(err);
  }
};

// @route   GET /api/media/my
// @access  Private
// @desc    Returns all media uploaded by the currently authenticated user, newest first.
const getMyMedia = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit, 10) || 24, 100);
    const skip = (page - 1) * limit;

    const [items, total] = await Promise.all([
      Media.find({ uploadedBy: req.user._id })
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Media.countDocuments({ uploadedBy: req.user._id }),
    ]);

    res.status(200).json({
      success: true,
      media: items.map((m) => m.toPublicJSON()),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/media
// @access  Private/Admin
// @desc    Returns every media item in the system, for admin moderation.
const getAllMedia = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
    const skip = (page - 1) * limit;

    const [items, total] = await Promise.all([
      Media.find({})
        .populate('uploadedBy', 'username email role')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Media.countDocuments({}),
    ]);

    res.status(200).json({
      success: true,
      media: items.map((m) => ({
        ...m.toPublicJSON(),
        uploadedBy: m.uploadedBy
          ? { id: m.uploadedBy._id, username: m.uploadedBy.username, email: m.uploadedBy.email }
          : null,
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/media/:id
// @access  Public
// @desc    Returns a single media item's metadata for the public view page.
const getMediaById = async (req, res, next) => {
  try {
    const media = await Media.findById(req.params.id);

    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media not found. It may have been deleted.',
      });
    }

    // Fire-and-forget view counter increment; doesn't block the response.
    Media.updateOne({ _id: media._id }, { $inc: { views: 1 } }).catch(() => {});

    res.status(200).json({
      success: true,
      media: media.toPublicJSON(),
    });
  } catch (err) {
    next(err);
  }
};

// @route   DELETE /api/media/:id
// @access  Private (owner or admin)
// @desc    Deletes a media item's DB record and its file on disk.
const deleteMedia = async (req, res, next) => {
  try {
    const media = await Media.findById(req.params.id);

    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media not found. It may already have been deleted.',
      });
    }

    const isOwner = media.uploadedBy && media.uploadedBy.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to delete this file.',
      });
    }

    const filePath = path.join(UPLOAD_DIR, media.filename);
    fs.unlink(filePath, (err) => {
      // Log but don't fail the request if the file was already missing from disk.
      if (err && err.code !== 'ENOENT') {
        console.error(`[media] Failed to remove file ${filePath}:`, err.message);
      }
    });

    await media.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Media deleted successfully.',
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { uploadMedia, getMyMedia, getAllMedia, getMediaById, deleteMedia };
