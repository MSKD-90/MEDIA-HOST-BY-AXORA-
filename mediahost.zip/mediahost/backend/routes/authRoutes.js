const express = require('express');
const { register, login, getMe } = require('../controllers/authController');
const { protect } = require('../middleware/auth');

const router = express.Router();

// POST /api/auth/register - create a new account
router.post('/register', register);

// POST /api/auth/login - authenticate and receive a JWT
router.post('/login', login);

// GET /api/auth/me - return the logged-in user's profile (requires Bearer token)
router.get('/me', protect, getMe);

module.exports = router;
