const express = require('express');
const {
  uploadMedia,
  getMyMedia,
  getAllMedia,
  getMediaById,
  deleteMedia,
} = require('../controllers/mediaController');
const { protect, optionalAuth, authorize } = require('../middleware/auth');
const { upload } = require('../middleware/upload');

const router = express.Router();

// POST /api/media/upload - upload a single image/video ("file" form field).
// optionalAuth: logged-in users get the upload attributed to their account,
// guests can still upload and receive a deleteHash to manage it later.
router.post('/upload', optionalAuth, upload.single('file'), uploadMedia);

// GET /api/media/my - the current user's own uploads (requires login)
router.get('/my', protect, getMyMedia);

// GET /api/media - every upload in the system (admin only)
router.get('/', protect, authorize('admin'), getAllMedia);

// GET /api/media/:id - public metadata for a single item, no auth required
router.get('/:id', getMediaById);

// DELETE /api/media/:id - owner or admin only
router.delete('/:id', protect, deleteMedia);

module.exports = router;
