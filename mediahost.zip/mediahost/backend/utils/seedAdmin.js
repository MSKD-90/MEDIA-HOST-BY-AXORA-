/**
 * One-off script to create (or promote) an admin user.
 * Usage: node utils/seedAdmin.js admin@example.com AdminUser SomeStrongPassword123
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');

const [, , email, username, password] = process.argv;

async function run() {
  if (!email || !username || !password) {
    console.log('Usage: node utils/seedAdmin.js <email> <username> <password>');
    process.exit(1);
  }

  await connectDB();

  let user = await User.findOne({ email: email.toLowerCase() });

  if (user) {
    user.role = 'admin';
    await user.save();
    console.log(`Existing user ${user.email} promoted to admin.`);
  } else {
    user = await User.create({ username, email, password, role: 'admin' });
    console.log(`Admin user created: ${user.email}`);
  }

  await mongoose.disconnect();
  process.exit(0);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
