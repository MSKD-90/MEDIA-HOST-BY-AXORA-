const jwt = require('jsonwebtoken');

// Signs a JWT carrying the minimum claims needed to identify the user.
// Keeping the payload small avoids leaking data through decoded tokens on the client.
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

module.exports = generateToken;
