# MediaHost

A production-ready, imgbb-style media hosting platform: drag-and-drop image/video
uploads, instant shareable links, a private dashboard, and an admin panel — built
on a clean, API-first REST backend.

```
mediahost/
  backend/    Node.js + Express + MongoDB API (see backend/README.md)
  frontend/   React + Vite + Tailwind UI    (see frontend/README.md)
```

## Quick start

You need Node.js 18+ and a MongoDB instance (local, Docker, or Atlas).

```bash
# 1. Backend
cd backend
npm install
cp .env.example .env        # edit MONGO_URI / JWT_SECRET as needed
npm run dev                  # http://localhost:5000

# 2. Frontend (in a second terminal)
cd frontend
npm install
cp .env.example .env        # VITE_API_URL=http://localhost:5000/api
npm run dev                  # http://localhost:5173
```

Open http://localhost:5173 — you can upload as a guest immediately, or
create an account to get a personal dashboard.

To create an admin account:

```bash
cd backend
npm run seed:admin -- admin@example.com admin StrongPassword123
```

Then log in with those credentials and visit `/admin`.

## What's included

**Auth**
- Register / login / `GET /api/auth/me`
- Bcrypt password hashing, JWT-based sessions, role-based middleware (`user` / `admin`)

**Media**
- `POST /api/media/upload` — image (`jpg/png/webp/gif`) or video (`mp4/webm`), up to 50MB by default
- `GET /api/media/my` — the logged-in user's own uploads, paginated
- `GET /api/media/:id` — public metadata for the shareable view page
- `DELETE /api/media/:id` — owner or admin only
- `GET /api/media` — every upload in the system, admin only

Full endpoint reference, request/response shapes, and curl examples are in
[`backend/README.md`](./backend/README.md).

**UI**
- Drag-and-drop upload zone with live per-file progress bars (parallel uploads)
- Instant thumbnail previews, copy-link buttons, delete-with-confirm
- Public, no-login media view page with an SEO-friendly document title
- Loading skeletons, toast notifications, responsive grid (mobile → desktop)

## Moving to cloud storage later

Files are currently stored on local disk under `backend/uploads/` and served
via `express.static`. To move to S3 / Cloudinary:

1. Swap the `multer.diskStorage` config in `backend/middleware/upload.js` for
   the relevant cloud storage engine (e.g. `multer-s3`, or upload the buffer
   to Cloudinary inside the controller).
2. Update how `publicUrl` is built in `backend/controllers/mediaController.js`
   to use the URL the cloud provider returns instead of `${BASE_URL}/uploads/...`.

Nothing else changes — the API contract, the `Media` model, and the entire
frontend are storage-agnostic.

## Security notes

- Passwords are bcrypt-hashed (12 rounds) and never returned by the API.
- JWTs are short-lived and configurable via `JWT_EXPIRES_IN`.
- Helmet security headers, a CORS allow-list (`CLIENT_ORIGINS`), and rate
  limiting (tighter on `/api/auth`) are all enabled by default.
- Uploaded filenames are randomized on disk; the original filename is kept
  only as display metadata.
- Before going to production: set a long random `JWT_SECRET`, restrict
  `CLIENT_ORIGINS` to your real domain(s), and put the API behind HTTPS.
